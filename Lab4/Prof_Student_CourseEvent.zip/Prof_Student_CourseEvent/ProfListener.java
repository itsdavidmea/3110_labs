public interface ProfListener {

    void handleMidtermDate(ProfEvent event);

    void handelPostopnedMidterm(ProfEvent event);
}
